
/*========================================================================*
 *                                                                        *
 *  Distributed by Whiteley Research Inc., Sunnyvale, California, USA     *
 *                       http://wrcad.com                                 *
 *  Copyright (C) 2018 Whiteley Research Inc., all rights reserved.       *
 *  Author: Stephen R. Whiteley, except as indicated.                     *
 *                                                                        *
 *  This software is provided under the terms and conditions of the       *
 *  MIT license as it applies the the FastHenry computer software.        *
 *                                                                        *
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,      *
 *   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES      *
 *   OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-        *
 *   INFRINGEMENT.  IN NO EVENT SHALL WHITELEY RESEARCH INCORPORATED      *
 *   OR STEPHEN R. WHITELEY BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER     *
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,      *
 *   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE       *
 *   USE OR OTHER DEALINGS IN THE SOFTWARE.                               *
 *                                                                        *
 *========================================================================*
 * Linear Algebra extensions to FastHenry
 *========================================================================*
 $Id:$
 *========================================================================*/

#include "solver.h"
#include "stdio.h"

/* #define DEBUG */

/* Exactly one of the defines referenced below should be defined in the
 * Makefile.
 */

// Original Berkeley Sparse solver package.
#ifdef SPARSE_SOLVER

void solver_message()
{
    fprintf(stdout,
        "Using SPARSE linear algebra package by Ken Kundert, UC Berkeley.\n");
}

#include "solver_sparse.c"
#endif

/* Intel MLK DSS solver. */
#ifdef DSS_SOLVER

void solver_message()
{
    fprintf(stdout, "Using Intel MKL/DSS linear algebra package.\n");
}

#include "solver_dss.c"
#endif

/* KLU (SuiteSparse) solver. */
#ifdef KLU_SOLVER

void solver_message()
{
    fprintf(stdout,
        "Using SuiteSparse linear algebra package by Tim Davis, Texas A&M.\n");
}

#include "solver_klu.c"
#endif

