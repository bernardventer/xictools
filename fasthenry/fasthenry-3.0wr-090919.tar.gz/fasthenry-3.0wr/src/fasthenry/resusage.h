/*!\page LICENSE LICENSE

Copyright (C) 2003 by the Board of Trustees of Massachusetts Institute of
Technology, hereafter designated as the Copyright Owners.

License to use, copy, modify, sell and/or distribute this software and
its documentation for any purpose is hereby granted without royalty,
subject to the following terms and conditions:

1.  The above copyright notice and this permission notice must
appear in all copies of the software and related documentation.

2.  The names of the Copyright Owners may not be used in advertising or
publicity pertaining to distribution of the software without the specific,
prior written permission of the Copyright Owners.

3.  THE SOFTWARE IS PROVIDED "AS-IS" AND THE COPYRIGHT OWNERS MAKE NO
REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, BY WAY OF EXAMPLE, BUT NOT
LIMITATION.  THE COPYRIGHT OWNERS MAKE NO REPRESENTATIONS OR WARRANTIES OF
MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF THE
SOFTWARE WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS TRADEMARKS OR OTHER
RIGHTS. THE COPYRIGHT OWNERS SHALL NOT BE LIABLE FOR ANY LIABILITY OR DAMAGES
WITH RESPECT TO ANY CLAIM BY LICENSEE OR ANY THIRD PARTY ON ACCOUNT OF, OR
ARISING FROM THE LICENSE, OR ANY SUBLICENSE OR USE OF THE SOFTWARE OR ANY
SERVICE OR SUPPORT.

LICENSEE shall indemnify, hold harmless and defend the Copyright Owners and
their trustees, officers, employees, students and agents against any and all
claims arising out of the exercise of any rights under this Agreement,
including, without limiting the generality of the foregoing, against any
damages, losses or liabilities whatsoever with respect to death or injury to
person or damage to property arising from or out of the possession, use, or
operation of Software or Licensed Program(s) by LICENSEE or its customers.

*/
/* # ***** sort to /src/header
   # ***** */
/* header where rusage and time structs are defined */

/* SRW ** Revised this:
 * getrusage is preferred, as it computes cpu time rather than wall-clock
 * time.  If getrusage is not available (as in MinGW) use gettimeofday.
 */

#include <sys/time.h>

static double dtime = 0.0;
static long sectime, utime;

#ifndef NO_RUSAGE
#include <sys/resource.h>

struct rusage timestuff;

/* SRW */
#ifdef SRW0814
#define SRWSECONDS \
static double srw_seconds() \
{ \
    getrusage(RUSAGE_SELF, &timestuff); \
    return (timestuff.ru_utime.tv_sec + 1.0e-6*timestuff.ru_utime.tv_usec); \
}
#endif

#define starttimer getrusage(RUSAGE_SELF, &timestuff); \
    sectime = timestuff.ru_utime.tv_sec; \
    utime = timestuff.ru_utime.tv_usec

#define stoptimer getrusage(RUSAGE_SELF, &timestuff); \
    dtime = (double)(timestuff.ru_utime.tv_sec - sectime) \
        + 1.0e-6*(double)(timestuff.ru_utime.tv_usec - utime)

#else /* NO_RUSAGE */

static struct timeval ru_tv;
static struct timezone ru_tz;

/* SRW */
#ifdef SRW0814
#define SRWSECONDS \
static double srw_seconds() \
{ \
    gettimeofday(&ru_tv, &ru_tz); \
    return (ru_tv.tv_sec + 1.0e-6*ru_tv.tv_usec); \
}
#endif

#define starttimer gettimeofday(&ru_tv, &ru_tz); \
    sectime = ru_tv.tv_sec; \
    utime = ru_tv.tv_usec

#define stoptimer gettimeofday(&ru_tv, &ru_tz); \
    dtime = (double)(ru_tv.tv_sec - sectime) \
        + 1.0e-6*(double)(ru_tv.tv_usec - utime)

#endif /* NO_RUSAGE */

